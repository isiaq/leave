module.exports = {
//   purge: [
//     './resources/**/*.blade.php',
//   ],
  darkMode: 'class', // or 'media' or 'class'
  theme: {
    extend: {},
  },
  variants: {
    extend: {},
  },
  plugins: [],
}
