To get started 
1. Clone the REPO
2. open the folder                                                                                                      
3. Run npm install (in cli) !important  
4. Run npm run dev (in cli) !important
5. Run php artisan serve (in cli). To start the server.

FOR EDITING 
1. the model - (theleaveform model and user model) represent items and entries in the database. it helps if you want to put items in the database
2. the controller - is where the logic is done and passesd to the view as {{ $varible }}
3. the view is the blade.php files 
4. The routes 

THE CONCEPT
1. There are 5 types of users. USER, ADMIN, SUPERVISOR, HOD and HR. Each has their own seperate routes and views


