<p>{{ $data['hod_name'] }} HOD of Department {{ $data['hod_department'] }}</p>
<p>Just applied for leave</p>
<p>Please check your dashboard for approval</p>
<p>From {{ $data['hod_email'] }}</p>
