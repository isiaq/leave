<p>Leave Form has been by HR Personnel{{ $data['name'] }}.</p>
<p>{{ $data['usersName'] }} your Leave has been approved</p>
<p>After approval from,</p>
<p>Supervisor {{ $data['superName'] }}, {{ $data['superEmail']}}</p>
<p>HOD {{ $data['hodName'] }}, {{ $data['hodEmail'] }}</p>
