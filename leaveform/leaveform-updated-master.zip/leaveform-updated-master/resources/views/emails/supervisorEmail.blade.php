{{-- supervisor --}}
<p>This supervisor {{ $data['name'] }} just approved for leave for {{ $data['usersName'] }}</p>
<p>Please check dashboard for approval</p>
