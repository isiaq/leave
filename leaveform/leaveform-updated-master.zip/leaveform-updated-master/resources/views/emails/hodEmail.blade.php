<p>{{ $data['usersName'] }} applied for leave, which has been approved by </p>
<p>Supervisor {{ $data['superName'] }}, {{ $data['superEmail'] }} and</p>
<p>HOD {{ $data['name'] }} </p>
<p>yours faithfully.</p>