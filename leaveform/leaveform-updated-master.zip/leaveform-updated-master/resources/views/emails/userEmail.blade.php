<p>{{ $data['name'] }} Just applied for leave</p>
<p>Please check dashboard for approval</p>
