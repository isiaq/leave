<p>Supervisor {{ $data['supervisor_name'] }}, {{ $data['supervisor_email'] }} just applied for leave. </p>
<p>From {{ $data['supervisor_department'] }}</p>
<p>Awaiting confirmation...</p>
<p>Please check your dashboard for approval</p>
