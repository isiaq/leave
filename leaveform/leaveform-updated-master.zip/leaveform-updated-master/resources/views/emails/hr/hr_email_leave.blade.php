<p>HR personnel {{ $data['name'] }} just applied for leave. </p>
<p>{{ $data['email'] }}</p>
<p>Awaiting confirmation</p>
